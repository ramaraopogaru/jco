Note that all of the files contained in this chapter should be deployed under the /webapps/sap directory under your Tomcat installation. You must use the same directory structure, so that the com.apress.ejsap Java package is picked up correctly.

Your installation structure should look like this:
<TOMCAT_HOME>/
	webapps/
		sap/

Copy and compile the Java source code using the same directory structure in order to test the Web application.