/*
 * This Implements an Incredibly boring application
 * that Austin made me write.
 */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
